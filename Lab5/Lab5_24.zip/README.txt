First move inside the Desdemona folder.

To create the minmax_bot.so bot use the command:
cd bots/MinimaxBot
make

To create the AB_bot.so bot use the command:
cd bots/AlphaBetaBot
make

To run the program use the command:
cd ..
cd ..
./bin/Desdemona ./bots/MinimaxBot/minmax_bot.so ./bots/AlphaBetaBot/AB_bot.so